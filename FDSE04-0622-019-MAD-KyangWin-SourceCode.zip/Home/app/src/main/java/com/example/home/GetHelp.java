package com.example.home;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class GetHelp extends AppCompatActivity {
    Button btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_help);

        TextView myDetail = (TextView) findViewById(R.id.tvDetail);
        myDetail.setText("\t\t\tEach Level, you can select one of three radio buttons. And then, you have to click submit button to check answer and Next button to go to another questions. If the time is up, you can't submit answer and auto change another question. When you answered all of the questions, your total score will print out at Another Page.");


        btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GetHelp.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}