package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Level0 extends AppCompatActivity {

    private TextView tvQuestion, tvScore, tvQuestionNo, tvTimer;
    private RadioButton radioButton;
    private RadioButton rb1, rb2, rb3;
    private Button btnNext;
    private RadioGroup radioGroup;

    int totalQuestions;
    int qCounter = 0;//to count questions

    private QuestionModel currentQuestion;//to hole question format

    ColorStateList dfRbColor;
    boolean answered;//to check player is selected one of three options
    int score;//to store player'  scores

    private List<QuestionModel> questionModelList;//to store multiple Qs

    private int[] myRandomNoArr;//to hold random index no.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level0);

        tvQuestion = findViewById(R.id.tvQuestion);
        tvQuestionNo = findViewById(R.id.tvQus);
        tvScore = findViewById(R.id.tvScore);

        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rbtn1);
        rb2 = findViewById(R.id.rbtn2);
        rb3 = findViewById(R.id.rbtn3);

        btnNext = findViewById(R.id.btnNext);
        dfRbColor = rb1.getTextColors();

        questionModelList = new ArrayList<>();
        addQuestion();

        totalQuestions = questionModelList.size();

        myRandomNoArr = new int[10];
        myRandomNoArr = new MyRandomNoArr().getRandomGenerateNoArr();
        showNextQuestion();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //to check all the questions are answered and then display players' scores
                if (btnNext.getText().toString().equals("Finish")) {
                    Intent intent = new Intent(Level0.this, total_score.class);

                    intent.putExtra("values", score);
                    startActivity(intent);
                }

                if (answered == false) {
                    //to check one option is selected
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked()) {
                        checkAnswer();
                    } else {
                        Toast.makeText(Level0.this, "Please select one of three", Toast.LENGTH_LONG).show();
                    }
                } else {
                    showNextQuestion();
                }
            }
        });
    }


    //set 10 Quesstions
    private void addQuestion() {

        questionModelList.add(new QuestionModel("8+5", "12", "13", "10", 2));
        questionModelList.add(new QuestionModel("1+1", "2", "3", "0", 1));
        questionModelList.add(new QuestionModel("7+2", "8", "9", "10", 2));
        questionModelList.add(new QuestionModel("3+3", "6", "8", "7", 1));
        questionModelList.add(new QuestionModel("1+4", "6", "5", "4", 2));
        questionModelList.add(new QuestionModel("6+2", "8", "9", "10", 1));
        questionModelList.add(new QuestionModel("8+3", "12", "13", "11", 3));
        questionModelList.add(new QuestionModel("10+2", "12", "13", "9", 1));
        questionModelList.add(new QuestionModel("7+3", "8", "9", "10", 3));
        questionModelList.add(new QuestionModel("3+1", "2", "4", "5", 2));
    }

    //compare stored data and selected answer
    private void checkAnswer() {
        answered = true;
        RadioButton rbSelected = findViewById(radioGroup.getCheckedRadioButtonId());
        int answerNo = radioGroup.indexOfChild(rbSelected) + 1;
        if (answerNo == currentQuestion.getCorrectAnsNo()) {
            MediaPlayer mediaPlayer = MediaPlayer.create(this,R.raw.success);
            mediaPlayer.start();
            score++;
            tvScore.setText("Score: " + score);
        }else {
            MediaPlayer mediaPlayer = MediaPlayer.create(this,R.raw.wrong);
            mediaPlayer.start();
        }
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);

        //to set correct ans text color to green
        switch (currentQuestion.getCorrectAnsNo()) {
            case 1:
                rb1.setTextColor(Color.GREEN);
                break;
            case 2:
                rb2.setTextColor(Color.GREEN);
                break;
            case 3:
                rb3.setTextColor(Color.GREEN);
                break;
        }
        //disable radio buttons when player' submit their selected option
        if (qCounter < totalQuestions) {
            btnNext.setText("Next");
            rb1.setEnabled(false);
            rb2.setEnabled(false);
            rb3.setEnabled(false);
        } else {
            btnNext.setText("Finish");
        }
    }
//to show another question
    private void showNextQuestion() {
        radioGroup.clearCheck();
        rb1.setTextColor(dfRbColor);
        rb2.setTextColor(dfRbColor);
        rb3.setTextColor(dfRbColor);

        if (qCounter < totalQuestions) {

            currentQuestion = questionModelList.get(myRandomNoArr[qCounter]);
            tvQuestion.setText(currentQuestion.getQuestion());
            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());

            qCounter++;
            btnNext.setText("Submit");

            //re-enable select for player
            rb1.setEnabled(true);
            rb2.setEnabled(true);
            rb3.setEnabled(true);
            tvQuestionNo.setText("Question " + qCounter + "/" + totalQuestions);
            answered = false;
        } else {
            finish();
        }
    }
}