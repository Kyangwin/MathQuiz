package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class total_score extends AppCompatActivity {
    Button btnNext;
    TextView score;
    int scores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_score);

        btnNext=findViewById(R.id.btnnext);
        score=findViewById(R.id.tvscore);
        Intent intent = getIntent();
        scores = intent.getIntExtra("values",0);
        score.setText("Total Score(s) : " +scores);

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1=new Intent(total_score.this,SecondActivity.class);
                startActivity(intent1);
            }
        });

    }
}