package com.example.home;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

public class Level2 extends AppCompatActivity {

    private TextView tvQuestion, tvScore, tvQuestionNo, tvTimer;

    private RadioButton radioButton;
    private RadioButton rb1, rb2, rb3;
    private Button btnNext;
    private RadioGroup radioGroup;

    int totalQuestions;
    int qCounter = 0;

    private QuestionModel currentQuestion;

    ColorStateList dfRbColor;
    boolean answered;

    int score;
    CountDownTimer countDownTimer;


    private List<QuestionModel> questionModelList;
    private int[] myRandomNoArr ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_level2);

        tvQuestion = findViewById(R.id.tvQuestion);
        tvQuestionNo = findViewById(R.id.tvQus);
        tvScore = findViewById(R.id.tvScore);
        tvTimer = findViewById(R.id.tvTime);

        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rbtn1);
        rb2 = findViewById(R.id.rbtn2);
        rb3 = findViewById(R.id.rbtn3);
        btnNext = findViewById(R.id.btnNext);
        dfRbColor = rb1.getTextColors();

        questionModelList = new ArrayList<>();
        addQuestion();

        totalQuestions = questionModelList.size();

        myRandomNoArr = new int[10];
        myRandomNoArr = new MyRandomNoArr().getRandomGenerateNoArr();
        showNextQuestion();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (btnNext.getText().toString().equals("Finish")) {
                    Intent intent = new Intent(Level2.this, total_score.class);

                    intent.putExtra("values", score);
                    startActivity(intent);
                }

                if (answered == false) {
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked()) {
                        checkAnswer();
                        countDownTimer.cancel();
                    } else {
                        Toast.makeText(Level2.this, "Please select one of three", Toast.LENGTH_LONG).show();

                    }
                } else {
                    showNextQuestion();
                }
            }
        });
    }
    private void addQuestion() {

        questionModelList.add(new QuestionModel("(8-4)+5", "8", "9", "10", 2));//0-9
        questionModelList.add(new QuestionModel("10/5", "2", "3", "0", 1));
        questionModelList.add(new QuestionModel("10/3", "1", "3", "2", 2));
        questionModelList.add(new QuestionModel("(12+1)-3", "12", "11", "10", 3));
        questionModelList.add(new QuestionModel("4*2", "5", "9", "8", 3));
        questionModelList.add(new QuestionModel("12-7", "5", "4", "6", 1));
        questionModelList.add(new QuestionModel("(2*2)-2", "1", "0", "2", 3));
        questionModelList.add(new QuestionModel("(5+4)(1)", "9", "8", "6", 1));
        questionModelList.add(new QuestionModel("2*0", "2", "0", "3", 2));
        questionModelList.add(new QuestionModel("(8*1)/4", "3", "2", "1", 2));



    }

    private void checkAnswer() {
        answered = true;
        RadioButton rbSelected = findViewById(radioGroup.getCheckedRadioButtonId());
        int answerNo = radioGroup.indexOfChild(rbSelected) + 1;
        if (answerNo == currentQuestion.getCorrectAnsNo()) {

            MediaPlayer mediaPlayer = MediaPlayer.create(this,R.raw.success);
            mediaPlayer.start();
            score++;
            tvScore.setText("Score: " + score);


        }
        else {
            MediaPlayer mediaPlayer = MediaPlayer.create(this,R.raw.wrong);
            mediaPlayer.start();
        }
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);

        switch (currentQuestion.getCorrectAnsNo()) {
            case 1:
                rb1.setTextColor(Color.GREEN);
                break;
            case 2:
                rb2.setTextColor(Color.GREEN);
                break;
            case 3:
                rb3.setTextColor(Color.GREEN);
                break;

        }


        if (qCounter < totalQuestions) {
            btnNext.setText("Next");

            rb1.setEnabled(false);
            rb2.setEnabled(false);
            rb3.setEnabled(false);

        } else {
            btnNext.setText("Finish");
        }
    }

    private void showNextQuestion() {
        radioGroup.clearCheck();
        rb1.setTextColor(dfRbColor);
        rb2.setTextColor(dfRbColor);
        rb3.setTextColor(dfRbColor);


        if (qCounter < totalQuestions) {
            currentQuestion = questionModelList.get(myRandomNoArr[qCounter]);

            Timer();
            tvQuestion.setText(currentQuestion.getQuestion());
            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());


            qCounter++;
            btnNext.setText("Submit");

            tvQuestionNo.setText("Question " + qCounter + "/" + totalQuestions);
            rb1.setEnabled(true);
            rb2.setEnabled(true);
            rb3.setEnabled(true);
            answered = false;
        } else {
            finish();
     }
}
    private void Timer() {
        countDownTimer = new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long l) {
                tvTimer.setText("00:" + l / 1000);
            }

            @Override
            public void onFinish() {
                showNextQuestion();
            }
        }.start();
    }
}